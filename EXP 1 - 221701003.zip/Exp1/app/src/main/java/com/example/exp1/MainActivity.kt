package com.example.exp1

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val myText = findViewById<TextView>(R.id.myText)
        val changeFontButton = findViewById<Button>(R.id.changeFontButton)
        val changeColorButton = findViewById<Button>(R.id.changeColorButton)

        changeFontButton.setOnClickListener {
            myText.setTypeface(null, Typeface.BOLD_ITALIC)
            Toast.makeText(this, "Font Changed!", Toast.LENGTH_SHORT).show()
        }

        changeColorButton.setOnClickListener {
            myText.setTextColor(Color.parseColor("#FF4081"))
            Toast.makeText(this, "Color Changed!", Toast.LENGTH_SHORT).show()
        }
    }
}
